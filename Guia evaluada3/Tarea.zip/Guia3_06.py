#6
for hora in range(24):
    for minuto in range(60):
        for segundo in range(60):
            print(f"{hora:00}:{minuto:01}:{segundo:01}")
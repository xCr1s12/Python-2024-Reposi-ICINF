a = 500
b = 456
c = 0
while a != 800:
    c += a 
    c += b
    a += 10
    b -= 2
c += 800
print("La sumatoria de el ejercicio es: ", c)